<?php
/*
* (c) 2015 Geis CZ s.r.o.
*/

class GeisPointModel
{
    public function __construct($detail) {
        $this->id_gp = $detail->id_gp;
        $this->id_region = $detail->id_region;
        $this->name = $detail->name;
        $this->city = $detail->city;
        $this->street = $detail->street;
        $this->zipcode = $detail->zipcode;
        $this->country = $detail->country;
        $this->email = $detail->email;
        $this->phone = $detail->phone;
        $this->openining_hours = $detail->openining_hours;
        $this->holiday = $detail->holiday;
        $this->map_url = $detail->map_url;
        $this->gpsn = $detail->gpsn;
        $this->gpse = $detail->gpse;
        $this->photo_url = $detail->photo_url;
        $this->note = $detail->note;
    }

    public $id_gp;
    public $id_region;
    public $name;
    public $city;
    public $street;
    public $zipcode;
    public $country;
    public $email;
    public $phone;
    public $openining_hours;
    public $holiday;
    public $map_url;
    public $gpsn;
    public $gpse;
    public $photo_url;
    public $note;
}