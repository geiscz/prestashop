<?php
/*
* (c) 2015 Geis CZ s.r.o.
*/

/**
 * @service GeisPointSoapClient
 */
class GeisPointSoapClient{
    /**
     * The WSDL URI
     *
     * @var string
     */
    public static $_WsdlUri='http://plugin.geispoint.cz/wsdl/wsdl.php?WSDL';
    /**
     * The PHP SoapClient object
     *
     * @var object
     */
    public static $_Server=null;

    /**
     * Send a SOAP request to the server
     *
     * @param string $method The method name
     * @param array $param The parameters
     * @return mixed The server response
     */
    public static function _Call($method,$param){
        ini_set('max_execution_time', 3);  
        try {
            if(is_null(self::$_Server))
//                self::$_Server=new SoapClientTimeout(self::$_WsdlUri,array('trace' => 1,
//                'exceptions'=> 1,
//                'connection_timeout'=> 3,
//                'max_execution_time'=>5
//                ));
                self::$_Server=new SoapClient(null,array('trace' => 1,
                'exceptions'=> 1,
                'location'=> 'http://plugin.geispoint.cz/wsdl/wsdl.php',
                'uri'=> 'http://plugin.geispoint.cz'
                ));

            
            $result = self::$_Server->__soapCall($method,$param);
        } catch (Exception $e) {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
            if(is_null(self::$_Server))
              self::$_Server=new SoapClient(null,array('trace' => 1,
                'exceptions'=> 1,
                'location'=> 'http://plugin.geispoint.cz/wsdl/wsdl.php',
                'uri'=> 'http://plugin.geispoint.cz'
                ));
            
            $result = self::$_Server->__soapCall($method,$param);
        }
        return $result;
    }

    /**
     * @param string $country_code
     * @return string
     */
    public function getRegions($country_code){
        return self::_Call('getRegions',Array(
            $country_code
        ));
    }

    /**
     * @param string $country_code
     * @param int $id_region
     * @return string
     */
    public function getCities($country_code,$id_region){
        return self::_Call('getCities',Array(
            $country_code,
            $id_region
        ));
    }

    /**
     * @param string $id_gp
     * @return string
     */
    public function getGPDetail($id_gp){
        return self::_Call('getGPDetail',Array(
            $id_gp
        ));
    }

    /**
     * @param string $zipcode
     * @param string $city
     * @param string $id_gp
     * @return string
     */
    public function searchGP($zipcode,$city,$id_gp){
        return self::_Call('searchGP',Array(
            $zipcode,
            $city,
            $id_gp
        ));
    }
}